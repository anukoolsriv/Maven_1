package com.lti;

public interface Calculator {
	public int add(int num1, int num2) throws IllegalArgumentException;

	public double div(int num1, int num2) throws IllegalArgumentException;
}
