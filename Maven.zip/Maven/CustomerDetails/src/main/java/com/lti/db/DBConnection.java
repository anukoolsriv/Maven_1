package com.lti.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	private Connection connection = null;
	private final String URL = "jdbc:oracle:thin:@localhost:1521:XE";
	private final String username="hr";
	private final String password="hr";
	
	public Connection getConnection() throws SQLException, ClassNotFoundException{
		if(connection == null){
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(URL,username,password);
		}
		return connection;
	}
	
	public String closeConnection() throws SQLException
	{
		String closed = "open";
		connection.close();
		connection = null;
		
		if(connection == null)
		{
			closed = "closed";
		}
		return closed;
	}
}
