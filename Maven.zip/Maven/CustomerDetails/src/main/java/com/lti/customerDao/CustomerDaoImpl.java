package com.lti.customerDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.customerBean.Customer;
import com.lti.db.DBConnection;

public class CustomerDaoImpl implements CustomerDao {

	@Override
	public int registerCustomer(Customer c) throws ClassNotFoundException, SQLException {
		DBConnection dbc = new DBConnection();
		String query = "insert into customer_detail(id, name, balance) values(cust_seq.nextval, ?, ?)";
		Connection connection = dbc.getConnection();

		PreparedStatement preparedStatement = connection.prepareStatement(query,
				PreparedStatement.RETURN_GENERATED_KEYS);
		preparedStatement.setString(1, c.getCustomerName());
		preparedStatement.setDouble(2, c.getCustomerBalance());

		int rs = preparedStatement.executeUpdate();

		return rs;
	}

	@Override
	public ArrayList<Customer> displayAllCustomers() throws SQLException, ClassNotFoundException {
		DBConnection dbc = new DBConnection();
		String query = "select * from customer_detail order by id";
		Connection connection = dbc.getConnection();

		PreparedStatement preparedStatement = connection.prepareStatement(query);

		ResultSet rs = preparedStatement.executeQuery();

		ArrayList<Customer> customerList = new ArrayList<>();

		while (rs.next()) {
			Customer customer = new Customer();
			customer.setCustomerId(rs.getInt(1));
			customer.setCustomerName(rs.getString(2));
			customer.setCustomerBalance(rs.getDouble(3));

			customerList.add(customer);
		}
		connection.close();

		return customerList;
	}

	@Override
	public int updateCustomer(Customer c) throws SQLException, ClassNotFoundException {
		DBConnection dbc = new DBConnection();
		String query = "update customer_detail set name = ?, balance = ? where id = ?";
		Connection connection = dbc.getConnection();

		PreparedStatement preparedStatement = connection.prepareStatement(query);
		preparedStatement.setString(1, c.getCustomerName());
		preparedStatement.setDouble(2, c.getCustomerBalance());
		preparedStatement.setInt(3, c.getCustomerId());

		int rs = preparedStatement.executeUpdate();

		return rs;
	}

	@Override
	public String deleteCustomer(int id) throws ClassNotFoundException, SQLException {
		DBConnection dbc = new DBConnection();
		String query = "delete from customer_detail where id = ?";

		Connection connection = dbc.getConnection();

		PreparedStatement preparedStatement = connection.prepareStatement(query);
		preparedStatement.setInt(1, id);

		int rs = preparedStatement.executeUpdate();
		String val = "";
		if (rs > 0) {
			val = "Records deleted " + rs;
		} else {
			val = "No record deleted";
		}
		return val;
	}

}
