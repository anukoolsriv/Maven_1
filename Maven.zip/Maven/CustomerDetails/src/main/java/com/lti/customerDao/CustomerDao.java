package com.lti.customerDao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.customerBean.Customer;

public interface CustomerDao {
	public int registerCustomer(Customer c) throws ClassNotFoundException, SQLException;
	public ArrayList<Customer> displayAllCustomers() throws SQLException, ClassNotFoundException;
	public int updateCustomer(Customer c) throws SQLException, ClassNotFoundException;
	public String deleteCustomer(int id) throws ClassNotFoundException, SQLException;
}
