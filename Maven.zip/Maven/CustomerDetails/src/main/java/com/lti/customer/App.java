package com.lti.customer;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.lti.customerBean.Customer;
import com.lti.customerservice.CustomerDetails;
import com.lti.customerservice.CustomerDetailsImpl;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner sc = new Scanner(System.in);

		do {
			System.out.println("Customer Details");
			System.out.println("1. Register a new Customer");
			System.out.println("2 Display All Customers");
			System.out.println("3. Update A Customer");
			System.out.println("4. Delete A Customer");

			System.out.println("Enter an option");
			int option = sc.nextInt();
			CustomerDetails customerDetails = null;
			Customer c = null;
			switch (option) {
			case 1:
				c = registerCustomer();
				customerDetails = new CustomerDetailsImpl();
				int registeredId = customerDetails.registerCustomer(c);
				System.out.println(registeredId + " record added");
				continue;
			case 2:
				displayAllCustomers();
				continue;
			case 3:
				c = updateCustomer();
				customerDetails = new CustomerDetailsImpl();
				int updatedId = customerDetails.updateCustomer(c);
				System.out.println(updatedId + " record updated");
				continue;
			case 4:
				int id = deleteCustomer();
				customerDetails = new CustomerDetailsImpl();
				String output = customerDetails.deleteCustomer(id);
				System.out.println(output);
				continue;
			default:
				break;
			}

		} while (true);
	}

	private static int deleteCustomer() {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter id to delete: ");
		int id = sc.nextInt();
		
		return id;
	}

	public static Customer registerCustomer() {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter name: ");
		String name = sc.next();
		System.out.println("Enter balance");
		double balance = sc.nextDouble();

		Customer c = new Customer();
		c.setCustomerName(name);
		c.setCustomerBalance(balance);

		return c;
	}

	public static Customer updateCustomer() {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter id to update: ");
		int id = sc.nextInt();

		System.out.println("Enter new name: ");
		String name = sc.next();
		System.out.println("Enter new balance");
		double balance = sc.nextDouble();

		Customer c = new Customer();
		c.setCustomerId(id);
		c.setCustomerName(name);
		c.setCustomerBalance(balance);

		return c;
	}

	public static void displayAllCustomers() throws ClassNotFoundException, SQLException {
		CustomerDetails customerDetailsImpl = new CustomerDetailsImpl();
		ArrayList<Customer> customers = customerDetailsImpl.displayAllCustomers();

		for (Customer c1 : customers) {
			System.out.println("Id: " + c1.getCustomerId());
			System.out.println("Name: " + c1.getCustomerName());
			System.out.println("Balance: " + c1.getCustomerBalance());

		}
	}
}
