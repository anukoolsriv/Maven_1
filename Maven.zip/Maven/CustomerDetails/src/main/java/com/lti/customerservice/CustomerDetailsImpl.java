package com.lti.customerservice;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.customerBean.Customer;
import com.lti.customerDao.CustomerDao;
import com.lti.customerDao.CustomerDaoImpl;

public class CustomerDetailsImpl implements CustomerDetails {

	@Override
	public int registerCustomer(Customer c) throws ClassNotFoundException, SQLException {
		CustomerDao customerDao = new CustomerDaoImpl();

		return customerDao.registerCustomer(c);
	}

	@Override
	public ArrayList<Customer> displayAllCustomers() throws ClassNotFoundException, SQLException {
		CustomerDao customerDaoImpl = new CustomerDaoImpl();
		return customerDaoImpl.displayAllCustomers();
	}

	@Override
	public int updateCustomer(Customer c) throws SQLException, ClassNotFoundException {
		CustomerDao customerDao = new CustomerDaoImpl();

		return customerDao.updateCustomer(c);

	}

	@Override
	public String deleteCustomer(int id) throws ClassNotFoundException, SQLException {
		
		CustomerDao customerDao = new CustomerDaoImpl();

		return  customerDao.deleteCustomer(id);
	}

}
